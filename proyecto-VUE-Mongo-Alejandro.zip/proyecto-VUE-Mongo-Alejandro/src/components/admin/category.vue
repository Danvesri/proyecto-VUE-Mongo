<template>
  <div>
    <h1>Categorias</h1>
  </div>
</template>