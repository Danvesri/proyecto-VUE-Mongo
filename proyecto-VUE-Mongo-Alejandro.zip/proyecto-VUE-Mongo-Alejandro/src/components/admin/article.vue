<template>
  <div>
    <h1>Articulos</h1>
  </div>
</template>