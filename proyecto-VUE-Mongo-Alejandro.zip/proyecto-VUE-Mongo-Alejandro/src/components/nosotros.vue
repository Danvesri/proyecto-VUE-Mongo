<template>
    <main class="container">
            <section class="row d-flex justify-content-evenly text-black">
                <div class="col-md-5 my-auto text-start">
                    <h1 class="color-marca">¿Quiénes somos?</h1>
                    <p class="lead">
                        Somos una empresa dedicada a la distribución de productos eléctricos y de ferretería a los diferentes municipios 
                        del Valle del Cauca, mediante el innovador y eficiente servicio; generando progreso y estabilidad a nuestros 
                        colaboradores, ya que ellos hacen posible la existencia de nuestra empresa y  siendo así un aliado estratégico de 
                        nuestros clientes a la hora de remodelar sus hogares.
                    </p>
                    <p class="lead">
                        Nuestra compañía inicia un proceso comercial en la ciudad de candelaria, donde se vio  un gran potencial  por su 
                        expansión gracias los nuevos proyectos de vivienda, actualmente buscamos  ser los mejores aliados de los propietarios 
                        de las viviendas y ser partícipes en hacer cumplir los sueños de los clientes ofreciendo una gran variedad de productos 
                        para la remodelación de sus hogares.
                    </p>
                </div>
                <div class="col-md-5 my-auto text-start">
                    <h2 class="color-marca">Misión</h2>
                    <p class="lead">
                        Ofrecer productos de calidad a nuestros clientes, contribuyendo a la mejora de sus viviendas y cumpliendo sus 
                        sueños de remodelar su hogar.
                    </p>
                    <h2 class="color-marca">Visión</h2>
                    <p class="lead">
                        Ser reconocidos como una empresa responsable con sus clientes, que brinda buen servicio y ofrece productos de 
                        calidad a nuestros clientes. Ser el mejor aliado del ferretero al proveer materiales de construcción y 
                        productos de ferretería.
                    </p>
                </div>
            </section>
        </main>
</template>