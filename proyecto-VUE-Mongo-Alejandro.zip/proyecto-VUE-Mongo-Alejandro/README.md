# Proyecto Ferretería

## Project setup
```
git clone https:https://github.com/MichaelGoonzalez/proyecto-VUE-Mongo.git
cd Plantilla-Vue-UTP
npm install
npm run serve
```

### Customize configuration
- See [Vue-Cli](https://cli.vuejs.org/config/).
- See [Vue-Router](https://router.vuejs.org/).
- See [Bootstrap-Vue](https://bootstrap-vue.org/).
