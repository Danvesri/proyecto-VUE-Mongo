var app = new Vue({
    el: "#app",
    data:{  

        productosArray : [
            {
                img:"../img/producto.png",
                nombreProducto:"Taladro percutor",
                descripcionProducto: "Taladro Percutor 1/2 pul 650w 3150RPM 47250GPM",
                precio: "$ 200.000"
            },
            {
                img:"../img/producto.png",
                nombreProducto:"Taladro percutor",
                descripcionProducto: "Taladro Percutor 1/2 pul 650w 3150RPM 47250GPM",
                precio: "$ 200.000"
            },
            {
                img:"../img/producto.png",
                nombreProducto:"Taladro percutor",
                descripcionProducto: "Taladro Percutor 1/2 pul 650w 3150RPM 47250GPM",
                precio: "$ 200.000"
            },
            {
                img:"../img/producto.png",
                nombreProducto:"Taladro percutor",
                descripcionProducto: "Taladro Percutor 1/2 pul 650w 3150RPM 47250GPM",
                precio: "$ 200.000"
            },
            {
                img:"../img/producto.png",
                nombreProducto:"Taladro percutor",
                descripcionProducto: "Taladro Percutor 1/2 pul 650w 3150RPM 47250GPM",
                precio: "$ 200.000"
            }     
        ],

        articulosArray: [
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
            {
                img: "../img/tutorial.png",
                clase: "Tutorial",
                titulo: "¿Cómo ajustar los muebles adecuadamente?",
                descripcion: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae laborum qui vero dignissimos" 
                +"provident, fuga cum illum eos voluptate rerum, est ipsam eum nesciunt? Sequi explicabo ipsam illum"
                +"laborum culpa!"

            },
        ]
    },
    methods:{

    }
})